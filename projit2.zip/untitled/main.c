#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define MAX_HEIGHT 1000


int print_next = 0;
int lprofile[MAX_HEIGHT];
int rprofile[MAX_HEIGHT];
int gap = 3;


struct node {

    char letter;
    int nbr;
    struct node* left;
    struct node* right;
};
typedef struct node *tree;

typedef struct asciinode asciinode;
struct asciinode
{
    asciinode * left, * right;

    //length of the edge from this node to its children
    int edge_length;

    int height;

    int lablen;

    //-1=I am left, 0=I am root, 1=right
    int parent_dir;

    //max supported unit32 in dec, 10 digits max
    char label[11];
};

void print_level(asciinode *node, int x, int level)
{
    int i, isleft;
    if (node == NULL) return;
    isleft = (node->parent_dir == -1);
    if (level == 0)
    {
        for (i=0; i<(x-print_next-((node->lablen-isleft)/2)); i++)
        {
            printf(" ");
        }
        print_next += i;
        printf("%s", node->label);
        print_next += node->lablen;
    }
    else if (node->edge_length >= level)
    {
        if (node->left != NULL)
        {
            for (i=0; i<(x-print_next-(level)); i++)
            {
                printf(" ");
            }
            print_next += i;
            printf("/");
            print_next++;
        }
        if (node->right != NULL)
        {
            for (i=0; i<(x-print_next+(level)); i++)
            {
                printf(" ");
            }
            print_next += i;
            printf("\\");
            print_next++;
        }
    }
    else
    {
        print_level(node->left,
                    x-node->edge_length-1,
                    level-node->edge_length-1);
        print_level(node->right,
                    x+node->edge_length+1,
                    level-node->edge_length-1);
    }
}


//this part fills in the edge length and height fields of the specified tree

int MAX(int a, int b){
    if(a>b)
        return a;
    return b;
}
int MIN(int a, int b){
    if(a<b)
        return a;
    return b;
}

void compute_lprofile(asciinode *node, int x, int y)
{
    int i, isleft;
    if (node == NULL) return;
    isleft = (node->parent_dir == -1);
    lprofile[y] = MIN(lprofile[y], x-((node->lablen-isleft)/2));
    if (node->left != NULL)
    {
        for (i=1; i <= node->edge_length && y+i < 100; i++)
        {
            lprofile[y+i] = MIN(lprofile[y+i], x-i);
        }
    }
    compute_lprofile(node->left, x-node->edge_length-1, y+node->edge_length+1);
    compute_lprofile(node->right, x+node->edge_length+1, y+node->edge_length+1);
}

void compute_rprofile(asciinode *node, int x, int y)
{
    int i, notleft;
    if (node == NULL) return;
    notleft = (node->parent_dir != -1);
    rprofile[y] = MAX(rprofile[y], x+((node->lablen-notleft)/2));
    if (node->right != NULL)
    {
        for (i=1; i <= node->edge_length && y+i < 100; i++)
        {
            rprofile[y+i] = MAX(rprofile[y+i], x+i);
        }
    }
    compute_rprofile(node->left, x-node->edge_length-1, y+node->edge_length+1);
    compute_rprofile(node->right, x+node->edge_length+1, y+node->edge_length+1);
}


void compute_edge_lengths(asciinode *node)
{
    int h, hmin, i, delta;
    if (node == NULL) return;
    compute_edge_lengths(node->left);
    compute_edge_lengths(node->right);

    /* first fill in the edge_length of node */
    if (node->right == NULL && node->left == NULL)
    {
        node->edge_length = 0;
    }
    else
    {
        if (node->left != NULL)
        {
            for (i=0; i<node->left->height && i < 100; i++)
            {
                rprofile[i] = -10000;
            }
            compute_rprofile(node->left, 0, 0);
            hmin = node->left->height;
        }
        else
        {
            hmin = 0;
        }
        if (node->right != NULL)
        {
            for (i=0; i<node->right->height && i < 100; i++)
            {
                lprofile[i] = 10000;
            }
            compute_lprofile(node->right, 0, 0);
            hmin = MIN(node->right->height, hmin);
        }
        else
        {
            hmin = 0;
        }
        delta = 4;
        for (i=0; i<hmin; i++)
        {
            delta = MAX(delta, gap + 1 + rprofile[i] - lprofile[i]);
        }

        //If the node has two children of height 1, then we allow the two leaves to be within 1, instead of 2
        if (((node->left != NULL && node->left->height == 1) ||
             (node->right != NULL && node->right->height == 1))&&delta>4)
        {
            delta--;
        }

        node->edge_length = ((delta+1)/2) - 1;
    }

    //now fill in the height of node
    h = 1;
    if (node->left != NULL)
    {
        h = MAX(node->left->height + node->edge_length + 1, h);
    }
    if (node->right != NULL)
    {
        h = MAX(node->right->height + node->edge_length + 1, h);
    }
    node->height = h;
}

struct asciinode * build_ascii_tree_recursive(tree  t)
{
    struct asciinode * node;

    if (t == NULL) return NULL;

    node = malloc(sizeof(asciinode));
    node->left = build_ascii_tree_recursive(t->left);
    node->right = build_ascii_tree_recursive(t->right);

    if (node->left != NULL)
    {
        node->left->parent_dir = -1;
    }

    if (node->right != NULL)
    {
        node->right->parent_dir = 1;
    }
    if(t->letter != '\0')
        sprintf(node->label, "%c", t->letter);
    else
        sprintf(node->label, "\\0");
    node->lablen = strlen(node->label);

    return node;
}


//Copy the tree into the ascii node structre
struct asciinode * build_ascii_tree(tree  t)
{
    struct asciinode *node;
    if (t == NULL) return NULL;
    node = build_ascii_tree_recursive(t);
    node->parent_dir = 0;
    return node;
}

//Free all the nodes of the given tree
void free_ascii_tree(asciinode *node)
{
    if (node == NULL) return;
    free_ascii_tree(node->left);
    free_ascii_tree(node->right);
    free(node);
}

//The following function fills in the lprofile array for the given tree.
//It assumes that the center of the label of the root of this tree
//is located at a position (x,y).  It assumes that the edge_length
//fields have been computed for this tree.

//prints ascii tree for given Tree structure
void print_ascii_tree(tree  t)
{
    asciinode *proot;
    int xmin, i;
    if (t == NULL) return;
    proot = build_ascii_tree(t);
    compute_edge_lengths(proot);
    for (i=0; i<proot->height && i < 100; i++)
    {
        lprofile[i] = 10000;
    }
    compute_lprofile(proot, 0, 0);
    xmin = 0;
    for (i = 0; i < proot->height && i < 100; i++)
    {
        xmin = MIN(xmin, lprofile[i]);
    }
    for (i = 0; i < proot->height; i++)
    {
        print_next = 0;
        print_level(proot, -xmin, i);
        printf("\n");
    }
    if (proot->height >= 100)
    {
        printf("(This tree is taller than %d, and may be drawn incorrectly.)\n",
               100);
    }
    free_ascii_tree(proot);
}


// makin' new nodes
tree createNode(char value,int nbr, tree LS, struct node* RS) {
    tree newNode = malloc(sizeof(struct node));


    newNode->letter = value;
    newNode->nbr = nbr;
    newNode->left = LS;
    newNode->right = RS;

    return newNode;
}

//movin' around
tree goR(struct node* root) {
    return root->right;
}

tree goL(struct node* root) {
    return root->left;
}






//Ci-dessous on trouve la fonction Insert
//Le principe de cette fonction est assez simple
//On compare une lettre d'une chaine de caractère avec l'attribut "lettre" de notre arbre
//S'ils sont égaux, nous allons nous déplacer vers le fils gauche du noeud courant et procéder aux traitements adéquats
//S'ils ne sont pas égaux, nous allons nous déplacer vers le fils droit du noeud courant et procéder ici aussi aux traitements adéquats
//Cette fonction a été faite d'une manière récursive afin d'alleger le code
tree insert(char *a, tree pa) {
    //On vérifie si le noeud courant est vide
    if (pa == NULL) {
        //On vérifie si le caractère courant est '\0' qui symbolise la fin d'un string en C
        if (a[0] == '\0') {
            //Création d'un noeud avec le nombre d'occurence égal à 1 vu que c'est la fin d'un mot
            pa = createNode(a[0], 1, NULL, NULL);
            return pa;
        }
        //S'il est different de '\0', on va alors inserer une nouvelle lettre
        //On convertit toutes les lettres en miniscules pour éviter l'ajout du même mot plusieurs fois s'il contient des majuscules
        a[0] = tolower(a[0]);
        //Création d'un nouveau noeud
        pa = createNode(a[0], 0, NULL, NULL);
        //Insertion du noeud dans le fils gauche
        pa->left = insert(a + 1, goL(pa));

    }
    //Si le noeud courant n'est pas vide, on va alors procéder à plusieurs traitement qui seront
    //Expliqué par la suite
    else {
        //On vérifie si le caractère courant est égale à l'attribut "lettre" de notre arbre
        if (a[0] == pa->letter) {
            //On vérifie par suite si le caractère est égale à '\0' afin d'incrémenter le nombre d'occurence si c'est le cas.
            if (a[0] == '\0') {
                pa->nbr++;
            }
                //Si ce n'est pas le cas, on insère le caractère courant dans le fils gauche du noeud
            else {
                pa->left = insert(a + 1, goL(pa));
            }

        }
            //Dans cette partie on traite le cas si le caractère courant
            //ne correspond pas à l'attribut "lettre" du noeud actuel
            //Cette insertion se fait bien-sûr selon un ordre alphabétique.
        else {
            //On compare les deux lettres
            //Si le code ASCII du caractère courant est supérieur à celui de l'attribut "lettre" du noeud, ça sera une simple insertion
            if (a[0] > pa->letter) {
                pa->right = insert(a, goR(pa));
            } //Si ce n'est pas le cas, il y aura une création d'un noeud temporaire
              //Qui prends comme fils droit le noeud courant et on continue le traitement par suite
            else {
                tree pp = createNode(a[0], 0, NULL, pa);
                pa = pp;
                pa->left = insert(a + 1, goL(pa));

            }

        }


    }

    return pa;
}

// nbr occurence mot

int nbrOcc(char *a, tree pa) {
    if (pa == NULL)
        return 0;
    if (a[0] == pa->letter) {
        if (a[0] == '\0') {
            return pa->nbr;
        }
        return nbrOcc(a + 1, pa->left);
    } else
        return nbrOcc(a, pa->right);
}









int main() {
    struct node *tr = NULL;

    char test[] = "ces";
    char test1[] = "bib";
    char test2[] = "ace";
    char test3[] = "deez";
    char test4[] = "dad";
    char test5[] = "des";
    char test6[] = "cAs";

    tr=insert(test,tr);
    print_ascii_tree(tr);






    tr=insert(test1,tr);

    tr=insert(test1,tr);


    tr=insert(test2,tr);


    tr=insert(test3,tr);

    tr=insert(test4,tr);
    print_ascii_tree(tr);
    tr=insert(test5,tr);
    tr=insert(test6,tr);

    printf("%d\n", nbrOcc(test, tr));
    printf("%d\n", nbrOcc(test1, tr));
    printf("%d\n", nbrOcc(test2, tr));
    printf("%d\n", nbrOcc(test3, tr));
    printf("%d\n", nbrOcc(test4, tr));
    printf("%d\n", nbrOcc(test5, tr));
    printf("%d\n", nbrOcc(test6, tr));






    getchar();
}
