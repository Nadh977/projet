#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>


struct node {

    char letter;
    int nbr;
    struct node* left;
    struct node* right;
};
typedef struct node *tree;


// makin' new nodes
tree createNode(char value,int nbr, tree LS, struct node* RS) {
    tree newNode = malloc(sizeof(struct node));


    newNode->letter = value;
    newNode->nbr = nbr;
    newNode->left = LS;
    newNode->right = RS;

    return newNode;
}

//movin' around
tree goR(struct node* root){
    return root->right;
}

tree goL(struct node* root)
{
    return root->left;
}


//insertin' around
tree insertLeft(tree root, char l) {
    root->left = createNode(l, 1, NULL, NULL);
    return root->left;
}

struct node* insertRight(tree root, char l) {
    root->right = createNode(l,1, NULL, NULL);
    return root->right;
}




//insert mot
tree insert(char *a, tree pa) {
    if (pa == NULL) {
        if (a[0] == '\0') {
            pa = createNode(a[0],1, NULL, NULL);
            return pa;
        }
        pa = createNode(a[0],1, NULL, NULL);
        pa->left = insert(a + 1, goL(pa));

    } else {
        if (a[0] == pa->letter) {

            pa->nbr++;

            if (a[0] != '\0') {
                pa->left =  insert(a + 1, goL(pa));
            }

        } else {


            pa->right = insert(a, goR(pa));

        }




    }

    return pa;
}

// nbr occurence mot

int nbrOcc(char *a, tree pa)
{
    if(pa==NULL)
        return 0;
    if (a[0] == pa->letter)
    {
        if(a[0]=='\0'){
            return pa->nbr;
        }
        return nbrOcc(a+1, pa->left);
    }
    else
        return nbrOcc(a, pa->right);
}









int main() {
    struct node *tr = NULL;

    char test[] = "cas";
    char test1[] = "ce";
    char test2[] = "ces";
    char test3[] = "ci";
    char test4[] = "de";
    char test5[] = "des";
    char test6[] = "do";

    tr=insert(test,tr);
    tr=insert(test,tr);
    tr=insert(test,tr);
    tr=insert(test,tr);


    tr=insert(test1,tr);
    tr=insert(test1,tr);


    tr=insert(test2,tr);


    tr=insert(test3,tr);
    tr=insert(test4,tr);
    tr=insert(test5,tr);
    tr=insert(test6,tr);
    printf("%d\n", nbrOcc(test, tr));
    printf("%d\n", nbrOcc(test1, tr));
    printf("%d\n", nbrOcc(test2, tr));
    printf("%d\n", nbrOcc(test3, tr));
    printf("%d\n", nbrOcc(test4, tr));
    printf("%d\n", nbrOcc(test5, tr));
    printf("%d\n", nbrOcc(test6, tr));






    getchar();
}
